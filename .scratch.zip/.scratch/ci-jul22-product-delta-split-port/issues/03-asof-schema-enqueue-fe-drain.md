Status: done

# As-of queue schema, FE enqueue, and live CPT drain

## Parent

PRD/plan: `.cursor/plans/ci-jul22-product-delta-split-port.prd.md`

## What to build

Deliver the live overnight as-of rewrite loop in the split repos.

1. Add `CreditAsOfRewriteQueue` (including `checkpoint_date`) to backend Prisma
   and ship the correct migration (full create vs additive column—see PRD
   discovery gate). Frontend regenerates its Prisma client from backend schema.
2. Port as-of rewrite queue helpers to the frontend; wire enqueue from Payment,
   Customer Top-Up, and Customer Policy mutations.
3. Update the frontend Customer Policy Trend Daily Snapshot cron wrapper so
   drain always runs after today’s snapshot attempt (even if today fails), with
   checkpoint resume, reclaim of stuck `processing` rows, skip when admin
   backfill is active, and unclean drain failing the job.
4. Port monolith unit tests for the queue and cron wrapper seams.
5. Copy the overnight as-of rewrite drain reliability PRD into both repos’
   `.cursor/plans/`.

Do not schedule Nest drain in this slice. Do not enable worker/BullMQ peel.

## Acceptance criteria

- [ ] Backend schema includes `CreditAsOfRewriteQueue` with `checkpoint_date`;
      migration applies cleanly to the shared DB shape in use
- [ ] Frontend Prisma client sees the queue model after generate from backend
      schema
- [ ] Payment, top-up, and customer policy mutations enqueue coalesced rewrite
      windows
- [ ] FE CPT cron always attempts drain after today snapshot; today failure does
      not skip drain
- [ ] Drain resumes from checkpoint, reclaims stuck processing, skips admin
      backfill accounts, and fails the job on unclean drain
- [ ] Ported queue + cron wrapper unit tests are green
- [ ] Overnight as-of drain PRD is present under `.cursor/plans/` in FE and BE
- [ ] Only FE cron is the scheduled drain (no second Nest schedule)

## How to test

1. Apply the migration; confirm the queue table/column exists.
2. Regenerate frontend Prisma client; confirm types include the queue model.
3. On a credit-insurance account, create/update a top-up (or policy/payment
   change that should enqueue); confirm a coalesced queue row appears.
4. Run the Customer Policy Trend Daily Snapshot job via the frontend cron path
   (or controlled local cron manager with crons enabled).
5. Confirm drain processes the row (or advances checkpoint); force a failure /
   stuck processing in unit tests to cover reclaim and fail-loudly behavior.
6. Confirm an active admin backfill causes skip for that account (unit or
   fixture).
7. Run ported unit tests for as-of queue and CPT cron wrapper.
8. Confirm Nest is not also scheduling drain for this queue.

## Blocked by

None — can start immediately (parallel with formula track)
