Status: ready-for-agent

# Nest as-of domain ready for cron cutover

## Parent

PRD/plan: `.cursor/plans/ci-jul22-product-delta-split-port.prd.md`

## What to build

Copy as-of rewrite queue enqueue/drain helpers into Nest credit-insurance
domain and hook drain onto Nest’s Customer Policy Trend snapshot entry so a
later cron cutover is a wiring change, not a rewrite.

Keep Nest drain **unscheduled**: do not enable Nest/worker as the live CPT cron
while frontend still drains. Document the single-scheduler constraint.

Port or adapt Nest-side unit tests for queue/drain behavior at the domain seam.

## Acceptance criteria

- [ ] Nest CI domain exposes enqueue/drain helpers equivalent to the FE/monolith
      queue behavior (checkpoint, reclaim, backfill skip, failure counts)
- [ ] Nest CPT snapshot entry can invoke drain (code path present)
- [ ] Nest drain is not scheduled in production/staging while FE CPT cron owns
      the job
- [ ] Nest domain queue/drain unit tests are green
- [ ] Cutover note remains: disable FE CPT cron for this job before enabling
      Nest schedule—never both

## How to test

1. Run Nest unit tests for as-of queue drain/enqueue helpers.
2. Confirm code wiring from Nest CPT snapshot entry to drain exists.
3. Inspect cron/scheduling config: FE still owns live CPT cron; Nest/worker does
   not double-schedule drain.
4. Optionally invoke Nest drain helper in a controlled non-prod script against
   a test queue row; do not leave a second schedule enabled.

## Blocked by

- `.scratch/ci-jul22-product-delta-split-port/issues/03-asof-schema-enqueue-fe-drain.md`
