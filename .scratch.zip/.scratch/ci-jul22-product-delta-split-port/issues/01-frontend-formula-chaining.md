Status: done

# Frontend formula chaining end-to-end

## Parent

PRD/plan: `.cursor/plans/ci-jul22-product-delta-split-port.prd.md`

## What to build

Port Report Builder formula chaining from the monolith Jul 22+ delta into the
frontend so editors can define formulas that reference other formula columns,
validate cycles/dependencies at edit time, and see stable ordered results in
the viewer and exports.

Bring over shared formula helpers (dependency ordering, edit-time expression
handling, validation), frontend report execution behavior, formula editor UI
updates, English/Hebrew strings for any new validation messages, and the
monolith unit tests for this seam. Copy related formula plan/PRD updates into
`.cursor/plans/`.

Do not add a shared npm package. Nest parity is a separate slice.

## Acceptance criteria

- [x] Editors can save a formula that references another formula column
- [x] Edit-time validation rejects cycles and unresolved formula dependencies
- [x] Chained formulas evaluate in a stable order on frontend report execute
- [x] Invalid chained results stay blank with warning summaries (not zero)
- [x] Viewer and export paths (CSV/Excel/PDF/scheduled as already wired) show
      chained values consistently with existing formula safety limits
- [x] Ported monolith unit tests for chaining/dependencies/execution are green
- [x] Related formula PRD/plan markdown is present under `.cursor/plans/`

## How to test

1. Open Report Builder on an account with formula editing permission.
2. Add formula A from numeric fields; save.
3. Add formula B that references formula A; save successfully.
4. Attempt a cyclic reference; confirm validation blocks save.
5. Run the report (ungrouped and grouped if applicable); confirm B uses A’s
   result and order is stable across re-runs.
6. Force an invalid row (e.g. divide by zero in the chain); confirm blank cell
   plus warning summary, not zero.
7. Export or open scheduled output if available; confirm chained columns match
   the viewer.
8. Run the ported frontend unit tests for report formula chaining.

## Blocked by

None — can start immediately
