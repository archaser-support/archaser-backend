Status: ready-for-agent

# Nest formula execute parity

## Parent

PRD/plan: `.cursor/plans/ci-jul22-product-delta-split-port.prd.md`

## What to build

Give Nest report execute the same formula chaining behavior as the frontend
path. Copy the formula core into Nest reports (dual copy—no new npm package)
and wire it into Nest `POST :id/execute` so chained formulas are applied, not
left as unused modules.

Port/adapt unit tests for formula helpers and execute behavior. Document
dual-copy sync debt in the PRD/plans notes if not already clear.

Review as a semantic pair with the frontend formula PR: Nest results must match
frontend for the same saved report config.

## Acceptance criteria

- [ ] Nest report execute applies chained formulas with the same dependency
      order as the frontend path
- [ ] Invalid chained calculations stay blank with warning summaries on Nest
      execute
- [ ] Existing formula safety limits are preserved (no `eval` / dynamic JS)
- [ ] Nest unit tests for formula helpers and execute chaining are green
- [ ] Manual smoke: same report config yields matching values on FE and Nest
      execute paths (when Nest execute is available in the env)

## How to test

1. Use a report saved in slice 01 with a two-step formula chain.
2. Execute via the frontend path; note values and warnings.
3. Execute the same report via Nest report execute (gateway or direct API with
   auth); compare values and warnings.
4. Run Nest unit tests covering formula dependency order and apply-to-rows /
   execute wiring.
5. If Nest execute is not routed in the env, still run Nest unit tests and note
   the informational gate from the PRD; FE smoke remains required from slice 01.

## Blocked by

- `.scratch/ci-jul22-product-delta-split-port/issues/01-frontend-formula-chaining.md`
